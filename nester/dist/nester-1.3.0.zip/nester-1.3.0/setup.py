from distutils.core import setup

setup(
    name    = 'nester',
    version = '1.3.0',
    py_modules  = ['nester'],
    author  =   'gendarme',
    author_email    = 'author@test.com',
    url = 'test.com',
    description = 'A simple printer of nested lists.',
)

"""
Q:\@Backup\@Project\Python\MyTest\nester\Python setup.py sdist
Q:\@Backup\@Project\Python\MyTest\nester\Python setup.py install
"""

